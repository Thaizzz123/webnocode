# PharmDoc — Cấu trúc dự án (đã tách thành phần)

File gốc `index.html` 1393 dòng đã được tách thành 8 file, gom theo đúng 4 nhóm chức năng: cấu hình/state, dữ liệu, engine gợi ý, giao diện. App vẫn chạy y hệt bản gốc, chỉ là code được phân chia rõ ràng hơn để trình bày.

```
PharmDoc/
├── index.html              # Khung giao diện: modal, header, trang Home, trang Search, footer
├── css/
│   └── style.css            # Toàn bộ CSS tuỳ chỉnh (badge, animation, scrollbar...)
└── js/
    ├── config.js             # APP_CONFIG (hằng số) + state (trạng thái UI hiện tại)
    ├── data.js                # Cơ sở dữ liệu 300 loại thuốc + bảng độ phổ biến
    ├── symptom-engine.js      # Engine gợi ý thuốc theo triệu chứng (tự xây, không gọi API ngoài)
    ├── render.js               # Routing trang, lọc dữ liệu, render thẻ thuốc, modal chi tiết
    ├── interactions.js          # Tìm kiếm, filter, chat, toast, dark mode, disclaimer
    └── app-init.js               # Điểm khởi chạy khi trang load xong
```

## Dùng cho thuyết trình thế nào

Mỗi file ứng với 1 "lát cắt" có thể trình bày riêng:

- **data.js** — cho thấy quy mô dữ liệu (300 thuốc, có phân loại OTC/Rx, tag triệu chứng).
- **symptom-engine.js** — phần lõi kỹ thuật, đáng nói nhất: thuật toán `recommendMedicines` chọn thuốc theo nguyên tắc phủ nhiều triệu chứng nhất, ưu tiên độ phổ biến, rồi ưu tiên OTC trước Rx, lặp lại đến khi hết triệu chứng hoặc hết thuốc phù hợp.
- **render.js / interactions.js** — phần giao diện, dễ demo trực quan trên màn hình khi đang thuyết trình.
- **config.js / app-init.js** — phần khởi tạo, giải thích nhanh trong 1-2 câu là đủ.

## Lưu ý kỹ thuật

Thứ tự load script trong `index.html` phải giữ đúng như hiện tại vì các file phụ thuộc lẫn nhau (`config.js` → `data.js` → `symptom-engine.js` → `render.js` → `interactions.js` → `app-init.js`). Đổi thứ tự sẽ gây lỗi `is not defined`.
